package com.example.weighttrackerproject;


import android.os.Bundle;

import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.example.weighttrackerproject.DBHandler;
import com.example.weighttrackerproject.ReadData;

import java.util.ArrayList;

public class ViewWeights extends grid {

    //Declare vairables
    private ArrayList<ReadData> readWeightsArrayList;
    private DBHandler dbHandler;
    private WeightRVAdapter weightRVAdapter;
    private RecyclerView weightsRV;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_view_weights);

        //Init variables
        readWeightsArrayList = new ArrayList<>();
        dbHandler = new DBHandler(ViewWeights.this);

        //Read the list of weights
        readWeightsArrayList = dbHandler.readWeights();

        //Pass the list to the adapter class
        weightRVAdapter = new WeightRVAdapter(readWeightsArrayList, ViewWeights.this);
        weightsRV = findViewById(R.id.idRVWeights);

        //Set layout manager
        LinearLayoutManager linearLayoutManager = new LinearLayoutManager(ViewWeights.this, RecyclerView.VERTICAL, false);
        weightsRV.setLayoutManager(linearLayoutManager);

        weightsRV.setAdapter(weightRVAdapter);
    }
}