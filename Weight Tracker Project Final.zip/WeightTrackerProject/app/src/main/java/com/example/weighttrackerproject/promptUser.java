package com.example.weighttrackerproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

public class promptUser extends AppCompatActivity {

    private TextView textAllow;
    private TextView textDontAllow;
    public boolean allowNotifications;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_prompt_user);

        textAllow = findViewById(R.id.textAllow);
        textDontAllow = findViewById(R.id.textDontAllow);

        textAllow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allowNotifications = true;
                //Open grid activity
                Intent i = new Intent(promptUser.this, grid.class);
                startActivity(i);
            }
        });

        textDontAllow.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                allowNotifications = false;
                //Open grid activity
                Intent i = new Intent(promptUser.this, grid.class);
                startActivity(i);
            }

        });

    }
}