package com.example.weighttrackerproject;

import static java.lang.Integer.parseInt;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.Toast;

public class grid extends AppCompatActivity {

    private EditText dateEdit, weightEdit, goalWeightEdit;
    private ImageButton addWeightButton;
    private DBHandler dbHandler;
    private Button showAllButton, smsButton;




    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_grid);

        //Initialize & find the views & variables
        dateEdit = findViewById(R.id.dateEdit);
        weightEdit = findViewById(R.id.weightEdit);
        addWeightButton = findViewById(R.id.addWeightButton);
        showAllButton = findViewById(R.id.showAllButton);
        smsButton = findViewById(R.id.smsButton);
        goalWeightEdit = findViewById(R.id.goalWeightEdit);

        final promptUser checkPromptUser = new promptUser();
        boolean checkPrompt = checkPromptUser.allowNotifications;

        //Create dbHandler instance
        dbHandler = new DBHandler(grid.this);

        // below line is to add on click listener for our add course button.
        addWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Store data in new string variables
                String date = dateEdit.getText().toString();
                String weight = weightEdit.getText().toString();
                String goalWeight = goalWeightEdit.getText().toString();

                //Check if entry is null
                if (date.isEmpty() && weight.isEmpty()) {
                    Toast.makeText(grid.this, "Some data is null, try again", Toast.LENGTH_SHORT).show();
                    return;
                }

                //Add the weight to the database
                dbHandler.addNewWeight(date, weight);

                if (parseInt(weight) == parseInt(goalWeight)) {
                    Toast.makeText(grid.this, "You have reached your goal weight!", Toast.LENGTH_SHORT).show();

                }
                //If log is successful, send message to user
                else {
                    Toast.makeText(grid.this, "Hurray! Weight has been logged.", Toast.LENGTH_SHORT).show();
                }
                dateEdit.setText("");
                weightEdit.setText("");
                goalWeightEdit.setText("");
            }
        });

        showAllButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // opening a new activity via a intent.
                Intent i = new Intent(grid.this, ViewWeights.class);
                startActivity(i);
            }
        });

        smsButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // opening a new activity via a intent.
                Intent i = new Intent(grid.this, promptUser.class);
                startActivity(i);
            }
        });
    }
}