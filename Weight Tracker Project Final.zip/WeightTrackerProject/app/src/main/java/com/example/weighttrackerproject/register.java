package com.example.weighttrackerproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

public class register extends AppCompatActivity {

    private Button joinButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_register);

        joinButton = (Button) findViewById(R.id.joinButton);
    }

    public void joinClicked(View view) {
        Intent intent = new Intent(this, grid.class);
        startActivity(intent);
    }
}