package com.example.weighttrackerproject;

import android.content.Context;
import android.content.Intent;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.RequiresPermission;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class WeightRVAdapter extends RecyclerView.Adapter<WeightRVAdapter.ViewHolder> {

    //Declare variables
    private ArrayList<ReadData> readWeightsArrayList;
    private Context context;

    //Default constructor
    public WeightRVAdapter(ArrayList<ReadData> readWeightsArrayList, Context context) {
        this.readWeightsArrayList = readWeightsArrayList;
        this.context = context;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        //Inflate layout view for recycler items
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.weight_rv_item, parent, false);
        return new ViewHolder(view);
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        //Set views equal to corresponding data
        ReadData readData = readWeightsArrayList.get(position);
        holder.dateTV.setText(readData.getDate());
        holder.weightTV.setText(readData.getWeight());

        holder.itemView.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {


                Intent i = new Intent(context, UpdateWeight.class);

                //Put items in intent
                i.putExtra("date", readData.getDate());
                i.putExtra("weight", readData.getWeight());

                context.startActivity(i);
            }
        });

    }

    @Override
    public int getItemCount() {
        //Returning the size of array list
        return readWeightsArrayList.size();
    }

    public class ViewHolder extends RecyclerView.ViewHolder {

        //Declare view objects
        private TextView dateTV, weightTV;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            //Find views
            dateTV = itemView.findViewById(R.id.idTVDates);
            weightTV = itemView.findViewById(R.id.idTVWeights);
        }
    }
}
