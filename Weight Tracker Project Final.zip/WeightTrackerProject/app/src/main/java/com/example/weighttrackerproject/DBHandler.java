package com.example.weighttrackerproject;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;

import java.util.ArrayList;
//import java.util.List;


public class DBHandler extends SQLiteOpenHelper {

    //Declare variables
    private static final int DATABASE_VERSION = 1;
    private static final String DATABASE_NAME = "weightDatabase";

    //Declare table name and columns
    private static final String TABLE_NAME = "weightDataTable";
    private static final String DATE_COL = "date";
    private static final String WEIGHT_COL = "weight";
    private static final String ID_COL = "id";

    //Default constructor
    public DBHandler(Context context) {
        super(context, DATABASE_NAME, null, DATABASE_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        //Create query for required columns
        String query = "CREATE TABLE " + TABLE_NAME + "("
                + ID_COL + " INTEGER PRIMARY KEY AUTOINCREMENT, "
                + DATE_COL + " TEXT,"
                + WEIGHT_COL + " TEXT)";

        db.execSQL(query);
    }

    //This method is use to add new weight to our sqlite database
    public void addNewWeight(String date, String weightInPounds) {
        //Create new database
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //Add date and weight values to columns in database
        values.put(ID_COL, (byte[]) null);
        values.put(DATE_COL, date);
        values.put(WEIGHT_COL, weightInPounds);


        db.insert(TABLE_NAME, null, values);
        //Close the database
        db.close();
    }

    public ArrayList<ReadData> readWeights() {
        //Create new database
        SQLiteDatabase db = this.getReadableDatabase();

        //Create new cursor to query all data in table
        Cursor cursorWeights = db.rawQuery("SELECT * FROM " + TABLE_NAME, null);

        //Declare new ArrayList
        ArrayList<ReadData> readWeightsArrayList = new ArrayList<>();

        //Cursor to first position
        if (cursorWeights.moveToFirst()) {
            do {
                //Add cursor data to the arraylist
                readWeightsArrayList.add(new ReadData(Integer.parseInt(cursorWeights.getString(0)),cursorWeights.getString(1),
                        cursorWeights.getString(2)));
            } while (cursorWeights.moveToNext());

        }
        //Return the arraylist
        cursorWeights.close();
        return readWeightsArrayList;
    }

    public void updateWeight(String originalDate, String date, String weight) {

        //Create new db
        SQLiteDatabase db = this.getWritableDatabase();
        ContentValues values = new ContentValues();

        //Put new items into values
        values.put(ID_COL, (byte[]) null);
        values.put(DATE_COL, date);
        values.put(WEIGHT_COL, weight);

        //Call the update method
        db.update(TABLE_NAME, values, "date=?", new String[]{originalDate});
        db.close();
    }

    public void deleteWeight(String date) {

        //Create new database
        SQLiteDatabase db = this.getWritableDatabase();

        //Delete the entry and close
        db.delete(TABLE_NAME, "date=?", new String[]{date});
        db.close();
    }


    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        //Check if table exists
        db.execSQL("DROP TABLE IF EXISTS " + TABLE_NAME);
        onCreate(db);
    }



}
