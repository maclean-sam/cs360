package com.example.weighttrackerproject;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

public class UpdateWeight extends AppCompatActivity {

    //Declare variables
    private EditText dateEdit, weightEdit;
    private Button updateWeightButton, deleteWeightButton;
    private DBHandler dbHandler;
    String dateVar, weightVar;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_update_weight);

        //Find view objects
        dateEdit = findViewById(R.id.idEditDate);
        weightEdit = findViewById(R.id.idEditWeight);

        updateWeightButton = findViewById(R.id.idButtonUpdateWeight);
        deleteWeightButton = findViewById(R.id.idButtonDeleteWeight);

        //Initialize dbHandler
        dbHandler = new DBHandler(UpdateWeight.this);

        //Get intents
        dateVar = getIntent().getStringExtra("date");
        weightVar = getIntent().getStringExtra("weight");

        //Set text to edit text
        dateEdit.setText(dateVar);
        weightEdit.setText(weightVar);


        //If update weight button is clicked
        updateWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                //Call the update weight method and convert edit text view objects to strings
                dbHandler.updateWeight(dateVar, dateEdit.getText().toString(), weightEdit.getText().toString());

                //If successful, display message that weight has been updated
                Toast.makeText(UpdateWeight.this, "Weight Updated!", Toast.LENGTH_SHORT).show();

                //Start grid activity
                Intent i = new Intent(UpdateWeight.this, grid.class);
                startActivity(i);
            }
        });

        //If delete weight button si clicked
        deleteWeightButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                //Delete the weight
                dbHandler.deleteWeight(dateVar);
                Toast.makeText(UpdateWeight.this, "Deleted the entry", Toast.LENGTH_SHORT).show();
                Intent i = new Intent(UpdateWeight.this, ViewWeights.class);
                startActivity(i);
            }
        });


    }
}