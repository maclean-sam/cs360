package com.example.weighttrackerproject;

public class ReadData {

    private String date;
    private String weight;
    private int id;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    //Create getter and setter methods
    public String getDate() {
        return date;
    }

    public void setDate(String date) {
        this.date = date;
    }

    public String getWeight() {
        return weight;
    }

    public void setWeight(String weight) {
        this.weight = weight;
    }


    //Default constructor
    public ReadData(int id, String date, String weight) {
        this.id = id;
        this.date = date;
        this.weight = weight;

    }
}
